package ie.atu.sw;

public class Runner {
	// The main method where the program execution starts
	public static void main(String[] args) throws Exception {
		// Create an instance of the Menu class and call the show method
		new Menu().show();
		
  	
	}
		}
	
	

	
